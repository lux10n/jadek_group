<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
  <link rel="icon" href="../images/fav.png">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body style="background:black;">

	<img class="wave" src="">
	<div class="container">
<!-- 		<div class="im">
			<img src="">
		</div>
 -->
    <div id="boxd">
 		<div class="login-content">
 			<form method="POST" action="../php_classes/adminprocess.php">
				<img src="img/avatar.png">
				<h2 class="title" style="color: white;text-transform: none;">Administrateurs</h2>
            	<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5 style="color: #fefefe;font-size: 12px;">ID Admin</h5>
           		   		<input type="text" class="input" id="adminID" name="adminID">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5 style="color: #fefefe;font-size: 12px;margin-left: 70%;">Clé Admin</h5>
           		    	<input type="date" class="input" id="adminkey" name="adminkey">
            	   </div>
            	</div>
            	<input type="submit" class="btn" value="Connexion">  
          </form>
        </div>
      </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>
