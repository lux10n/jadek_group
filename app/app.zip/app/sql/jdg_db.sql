-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mar. 21 juil. 2020 à 17:24
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `jdg_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `idadmin` int(11) NOT NULL AUTO_INCREMENT,
  `adminID` varchar(45) NOT NULL,
  `adminkey` date NOT NULL,
  PRIMARY KEY (`idadmin`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`idadmin`, `adminID`, `adminkey`) VALUES
(1, 'JDG1237654', '2020-07-21');

-- --------------------------------------------------------

--
-- Structure de la table `hotel_reserv`
--

DROP TABLE IF EXISTS `hotel_reserv`;
CREATE TABLE IF NOT EXISTS `hotel_reserv` (
  `idhotel_reserv` int(11) NOT NULL AUTO_INCREMENT,
  `nomreservant` varchar(45) NOT NULL,
  `type_pm` varchar(20) NOT NULL,
  `num_cc` varchar(45) NOT NULL,
  `nomhotel` varchar(20) NOT NULL,
  `typechambre` varchar(20) NOT NULL,
  `date_entree` date NOT NULL,
  `date_sortie` date NOT NULL,
  PRIMARY KEY (`idhotel_reserv`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `matchplan`
--

DROP TABLE IF EXISTS `matchplan`;
CREATE TABLE IF NOT EXISTS `matchplan` (
  `idmatchplan` int(11) NOT NULL AUTO_INCREMENT,
  `journee` varchar(1) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `match_id` varchar(1) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `stade` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ville` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `adv1` varchar(2) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `adv2` varchar(2) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idmatchplan`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `matchplan`
--

INSERT INTO `matchplan` (`idmatchplan`, `journee`, `match_id`, `stade`, `ville`, `adv1`, `adv2`) VALUES
(1, '1', '1', 'ebimpe', 'abidjan', 'et', 'bj'),
(2, '1', '2', 'fhb', 'abidjan', 'eg', 'mg'),
(3, '2', '1', 'bouake', 'bouake', 'ci', 'ml'),
(4, '2', '2', 'yakro', 'yamoussoukro', 'ma', 'gn'),
(5, '3', '1', 'korhogo', 'korhogo', 'cv', 'na'),
(6, '3', '2', 'bouake', 'bouake', 'eg', 'mr'),
(7, '4', '1', 'sanpedro', 'sanpedro', 'ke', 'tg'),
(8, '4', '2', 'yakro', 'yamoussoukro', 'za', 'ne'),
(9, '5', '1', 'sanpedro', 'sanpedro', 'cm', 'ug'),
(10, '5', '2', 'ebimpe', 'abidjan', 'rw', 'bf'),
(11, '6', '1', 'korhogo', 'korhogo', 'bi', 'gh'),
(12, '6', '2', 'fhb', 'abidjan', 'cd', 'mz'),
(13, '7', '1', 'sanpedro', 'sanpedro', 'rw', 'ma'),
(14, '7', '2', 'ebimpe', 'abidjan', 'eg', 'mr'),
(15, '8', '1', 'yakro', 'yamoussoukro', 'na', 'ke'),
(16, '8', '2', 'ebimpe', 'abidjan', 'ci', 'ma');

-- --------------------------------------------------------

--
-- Structure de la table `match_reserv`
--

DROP TABLE IF EXISTS `match_reserv`;
CREATE TABLE IF NOT EXISTS `match_reserv` (
  `idmatch_reserv` int(11) NOT NULL AUTO_INCREMENT,
  `nomreservant` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type_pm` varchar(15) NOT NULL,
  `num_cc` varchar(45) NOT NULL,
  `typeplace` varchar(10) NOT NULL,
  `journee` varchar(45) NOT NULL,
  `matchnum` varchar(11) NOT NULL,
  PRIMARY KEY (`idmatch_reserv`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `match_reserv`
--

INSERT INTO `match_reserv` (`idmatch_reserv`, `nomreservant`, `type_pm`, `num_cc`, `typeplace`, `journee`, `matchnum`) VALUES
(14, 'Abubakar Adnan', 'visa', 'NDI1NDc4OTU2MzI0NTY3OA==', 'vip', '2', '1');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `iduser` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `firstname` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(45) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `origin` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(1) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `numtel` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type_pm` varchar(20) NOT NULL,
  `num_cc` varchar(160) NOT NULL,
  `pp` varchar(50) DEFAULT NULL,
  `confirmcode` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`iduser`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`iduser`, `username`, `password`, `firstname`, `lastname`, `email`, `origin`, `gender`, `numtel`, `type_pm`, `num_cc`, `pp`, `confirmcode`) VALUES
(20, 'adnan', '81dc9bdb52d04dc20036dbd8313ed055', 'Abubakar', 'Adnan', 'abuadnan@gmail.com', 'mali', 'M', '+22551428916', 'visa', 'NDI1NDc4OTU2MzI0NTY3OA==', NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
