<?php
   class Identification{    
    public function __construct(){
      session_start();
    }
    public function connexion($tab){
      if(!empty($tab['login'])){
        $login = $tab['login'];
        $mdp = md5(htmlentities($tab['mdp']));  
            include('config.php');
         $connect = mysqlili_connect($MYHOST, $MYUSER, $MYPASS) or die('indentifiants incorrercts');
                 mysqli_select_db($connect, $MYDB) or die('Base de donnée incorrecte');
        
        //requete d'authentification 
        $requete = 'SELECT * FROM user WHERE username="'.$login.'" AND password="'.$mdp.'"';
        $result = mysqlili_query($connect, $requete);
        $row = mysqlili_fetch_assoc($result);
        //$utilisateur = mysqlil_fetch_assoc($result);
        if(mysqlili_num_rows($result) == 1){
          $_SESSION['connecte'] = true;
          $_SESSION['idadmin'] = $row['idadmin'];
          $_SESSION['Nom'] = $row['Nom'];
          $_SESSION['username'] = $row['username'];
          header('Location:Acceuil.php');
        }
        }
        else
        return false;
        mysqli_close($connect);
    } 
      
    public function deconnexion(){
      session_destroy();
      unset($_SESSION);
    }
    
    public function verificationAcces(){
      if(!$_SESSION['connecte'] == true)
        header('Location:./index.php');
    }
    function resetPassword($tab) { 
      if(!empty($tab['login'])) {
        $affichage = "";
        $login= htmlentities($tab['login']);
        $mail225 = "christjunior2013@live.fr";
        include('config.php');
        $connect = mysqlil_connect(MYHOST, MYUSER, MYPASS)  or die ('Identifiants incorrects');
        mysqli_select_db($connect, $MYDB) or die ('Base de données incorrecte');
        $requete = 'SELECT * FROM user WHERE username=\''.$login.'\'';
        //echo $requete;
        $result = mysqli_query($requete);
        $utilisateur = mysqli_fetch_assoc($result);
        if(mysqli_num_rows($result) == 1){
          $newpass = substr(md5($login.date("Y-m-d H:i:s")),2,10);
          $requete = 'UPDATE user SET password=\''.$mdp = md5(sha1(md5(htmlentities($newpass)))).'\' WHERE username=\''.$login.'\'';
          mysqlil_query($requete);
          $message = 'RENOUVELLEMENT DE MOT DE PASSE !';
          $message .= '<br/>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++<br/><br/>';
          $message .= 'Votre nouveau mot de passe est : <em style="color:red; font-size:24px; font-weight:700;">'.$newpass.'</em>';
          $message .= '<br/><br/>Nous vous remercions pour votre confiance! <br/>';
          $message .= '<br/>+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++<br/><br/>';
          $message = wordwrap($message, 70);
      // Pour envoyer un mail HTML, l'en-tête Content-type doit être défini
          $headers  = 'MIME-Version: 1.0' . "\r\n";
          $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
       
    // En-têtes additionnels
          $headers .= 'To: '.$login. "\r\n";
          $headers .= 'From: MOT DE PASSE <'.$mail225.'>' . "\r\n";
          $headers .= 'Reply-To: MOT DE PASSE <'.$mail225.'>' . "\r\n";
    
    // Envoi du mail
          mail($login, 'RENOUVELLEMENT DE MOT DE PASSE', $message, $headers);  
          echo "<br/><em style='color:green; font-size:14px; font-weight:900;'>Un nouveau passe vous a été envoyé, Veuillez consulter votre courriel (mail) svp!<br/>
            Cliquer <a href='index.php'>ici</a> pour accéder à la page d'authentification.</em>";
    //echo $newpass;
        return true;
        }
        return false;
        mysqlil_close($connect);
        }
        else{
        return true;
      }
    }
    public function modifiermdp($tab){
      if(!empty($tab['login'])){
        $login = htmlentities($tab['login']);
        $mdp1 = md5(sha1(md5(htmlentities($tab['mdp1']))));
        $mdp2 = md5(sha1(md5(htmlentities($tab['mdp2']))));
        include('config.php');
        $connect = mysqli_connect(MYHOST, MYUSER, MYPASS)  or die ('Identifiants incorrects');
mysqli_select_db($connect, $MYDB) or die ('Base de données incorrecte');
        $requete = 'SELECT * FROM user WHERE username=\''.$login.'\'';
        $result = mysqlil_query($requete);
        $utilisateur = mysqlil_fetch_assoc($result);
        if((mysqlil_num_rows($result) == 1) && ($mdp1 == $mdp2)){
        $requete = 'UPDATE username SET password=\''.$mdp1.'\' WHERE username=\''.$login.'\'';
        $result = mysqlil_query($requete);
        if($result == 1){
          echo '<script>alert("Modification effectuée avec succès!")</script>';
          return true;
        }
        return false;
        mysqlil_close($connect);
        }
        else{
        return true;
       }    
      }
    }    
   }
?>