<?php
	$connection = mysqli_connect('localhost', 'root', '');
	if (!$connection){
	    die("Database Connection Failed" . mysqli_error($connection));
	}
	$select_db = mysqli_select_db($connection, 'jdg_db');
	if (!$select_db){
	    die("Database Selection Failed" . mysqli_error($connection));
	}
	if (isset($_POST['username']) and isset($_POST['password'])){
		
		// Assigning POST values to variables.
		$username = $_POST['username'];
		$password = sha1(htmlentities($_POST['password']));

		// CHECK FOR THE RECORD FROM TABLE
		$query = "SELECT * FROM `user` WHERE username='$username' and password='$password'";
		$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
		$row= mysqli_fetch_array($result);
		$count = mysqli_num_rows($result);
		if ($count == 1){
			session_start();
			$_SESSION['uname']=$username;
			$_SESSION['pwd']=$password;
			$_SESSION['ID']=$row["customerID"];
			$_SESSION['gender']=$row["gender"];
			$_SESSION['fname']=$row["firstname"];
			$_SESSION['lname']=$row["lastname"];
			$_SESSION['mail']=$row["email"];
			$_SESSION['org']=$row["origin"];
			header('Location: ../account');

		}
		else{
			echo "<script type='text/javascript'>alert('Identifiants incorrects. Veuillez rééssayer.')</script>";
		}
	}
?>