<?php 
  $connection=mysqli_connect('localhost','root','') or die("Connection Error");
  $db=mysqli_select_db($connection,'jdg_db');
  if(isset($_POST['create'])){
    $firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $gender=$_POST['gender'];
    $origin=$_POST['origin'];
    $email=$_POST['email'];
    $numtel=$_POST['numtel'];
    $username=$_POST['username'];
    $password=sha1(htmlentities($_POST['password']));
    $type_pm=$_POST['type_pm'];
    $num_cc=htmlentities($_POST['num_cc']);
    $cID=sha1(date('s').random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9));
    $verif=mysqli_num_rows(mysqli_query($connection, "SELECT * FROM user WHERE username='$username' AND password='$password'"))==0;
    if($verif){
      $sql="INSERT INTO user (firstname,lastname,gender,origin,email,numtel,username,password,customerID,num_cc,type_pm) 
      VALUES ('$firstname','$lastname','$gender','$origin','$email','$numtel','$username','$password','$cID','$num_cc','$type_pm')";
      $result=mysqli_query($connection,$sql) or die(mysqli_error($connection));
      header('Location: ../login/');
    }
    elseif (mysqli_num_rows(mysqli_query($connection, "SELECT * FROM user WHERE username='$username' AND password='$password'"))>=1) {
      echo('<script>alert("Ce compte existe déjà. Veuillez vous connecter ou changer vos identifiants.")</script>');
  }
    else{
      // echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM user WHERE customerID='$cID'"));
      echo('<script>alert("Une erreur s\'est produite. Veuillez rééssayer. ('.mysqli_num_rows(mysqli_query($connection, "SELECT * FROM user WHERE username='$username' AND password='$password'")).')")</script>');
    }
  }
?>