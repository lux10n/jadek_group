<?php
	$connection = mysqli_connect('localhost', 'root', '');
	if (!$connection){
	    die("Database Connection Failed" . mysqli_error($connection));
	}
	$select_db = mysqli_select_db($connection, 'jdg_db');
	if (!$select_db){
	    die("Database Selection Failed" . mysqli_error($connection));
	}
	if (isset($_POST['adminID']) and isset($_POST['adminkey'])){
		
	// Assigning POST values to variables.
	$adminID = $_POST['adminID'];
	$adminkey = $_POST['adminkey'];

	// CHECK FOR THE RECORD FROM TABLE
	$query = "SELECT * FROM `admin` WHERE adminID='$adminID' and adminkey='$adminkey'";
	$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
	$row= mysqli_fetch_array($result);
	$count = mysqli_num_rows($result);

	if ($count == 1){

	//echo "Login Credentials verified";
	header('Location: admin/admins.php');
	}else{
	echo "<script type='text/javascript'>alert('Invalid Login Credentials')</script>";
	//echo "Invalid Login Credentials";
	sleep(2);
	header('Location: ../resp/admin.php');

	}
	}
?>