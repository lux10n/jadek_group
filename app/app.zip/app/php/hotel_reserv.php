<?php 
	$db_user="root";
	$db_pass="";
	$db_name="jdg_db";
	$db = new PDO('mysql:host=localhost;dbname='.$db_name.';charset=utf8', $db_user, $db_pass);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	if(isset($_POST['reserve'])){
		
		$password=md5($_POST['password']);
		$connection = mysqli_connect('localhost', 'root', '') or die("Database Connection Failed" . mysqli_error($connection));
		$select_db = mysqli_select_db($connection, 'jdg_db') or die("Database Selection Failed" . mysqli_error($connection));

		$query = "SELECT * FROM `user` WHERE password='$password'";
		$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
		$row= mysqli_fetch_array($result);

		$nomreservant=$row['firstname'].' '.$row['lastname'];
		$type_pm=$row['type_pm'];
		$num_cc=$row['num_cc'];
		$typechambre=$_POST['typechambre'];
		$nomhotel=$_POST['nomhotel'];
		$date_entree=$_POST['date_entree'];
		$date_sortie=$_POST['date_sortie'];
		$sql="INSERT INTO hotel_reserv ( nomreservant, type_pm, num_cc, nomhotel, typechambre	, date_entree, date_sortie) VALUES(?,?,?,?,?,?,?)";
		$stmtinsert=$db->prepare($sql);
		$result=$stmtinsert->execute([$nomreservant, $type_pm, $num_cc, $nomhotel, $typechambre, $date_entree, $date_sortie]);
		if($result){
			header("Location: ../OK.php");
		}
		else{
			echo('Try again.');
		}
	}
?>