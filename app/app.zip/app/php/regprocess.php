<?php 
	$connection=mysqli_connect('localhost','root','') or die("Connection Error");
	$db=mysqli_select_db($connection,'jdg_db');
	if(isset($_POST['create'])){
		$firstname=$_POST['firstname'];
		$lastname=$_POST['lastname'];
		$gender=$_POST['gender'];
		$origin=$_POST['origin'];
		$email=$_POST['email'];
		$numtel=$_POST['numtel'];
		$username=$_POST['username'];
		$password=$_POST['password'];
		$type_pm=$_POST['type_pm'];
		$num_cc=$_POST['num_cc'];
		$cID=sha1(date('s').random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9).random_int(1,9));
		$sql="INSERT INTO user (firstname,lastname,gender,origin,email,numtel,username,password,customerID,type_pm,num_cc) VALUES ('$firstname','$lastname','$gender','$origin','$email','$numtel','$username','md5($password)','$cID','$type_pm','base64_encode($num_cc)')";
		$result=mysqli_query($connection,$sql) or die(mysqli_error($connection));
		$res=mysqli_query($connection, "SELECT * FROM user WHERE customerID='$cID'");
		$verif=mysqli_num_rows($res)==1;
		if($verif){
			session_start();
			$_SESSION['uid']=mysqli_fetch_array($res)['iduser'];
			$_SESSION['uname']=$username;
			$_SESSION['pwd']=$password;
			$_SESSION['ID']=$cID;
			$_SESSION['gender']=$gender;
			$_SESSION['fname']=$firstname;
			$_SESSION['lname']=$lastname;
			$_SESSION['mail']=$email;

			header("Location: ../public/login/");
		}
		else{
			// echo mysqli_num_rows(mysqli_query($connection, "SELECT * FROM user WHERE customerID='$cID'"));
			echo('<script>alert("Identifiants non reconnus. Veuillez rééssayer.")</script>');
		}
	}
?>