<?php
	$MYHOST='localhost';
	$MYUSER='root';
	$MYPASS='toor';
	$MYDATABASE='';
?>