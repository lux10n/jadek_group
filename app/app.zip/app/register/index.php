<?php 
  require '../php/reg.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Inscription - JDG</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfairsplay:400,400i,700,700i" rel="stylesheet">
    <link rel="icon" href="../img/profiles/fav.png">
    <link rel="stylesheet" href="../css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../css/animate.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <link rel="stylesheet" href="../css/aos.css">
    <link rel="stylesheet" href="../css/ionicons.min.css">
    <link rel="stylesheet" href="../css/flags/css/flag-icon.css">
    <link rel="stylesheet" href="../css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../css/jquery.timepicker.css">
    <link rel="stylesheet" href="../css/flaticon.css">
    <link rel="stylesheet" href="../css/icomoon.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="register.css">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg ftco_navbar bg-transparent ftco-navbar-light" id="ftco-navbar">
      <div class="container">
        <a class="navbar-brand" href="index.php" style="color:black;">Jadek Group</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu" style="color: black;"></span><span style="color:black;">Menu</span>
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="../" class="nav-link" style="color: black;">Accueil</a></li>
            <li class="nav-item active"><a href="./" class="nav-link" style="color:#2095fe;">Inscription</a></li>
            <li class="nav-item"><a href="../login/" class="nav-link" style="color:black;">Connexion</a></li>
            <li class="nav-item"><a href="../account/" class="nav-link" style="color:black;">Mon compte</a></li>
            <li class="nav-item"><a href="../reservations/" class="nav-link" style="color:black;">Réservations</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->  
    <section class="ftco-section">
      <h1 style="text-align: center;font-family: 'Open Sans';text-transform: uppercase;margin-top: 5%;color:black;">Inscription</h1>
      <h2 style="text-align: center;font-family: 'Open Sans';color:black;">Pour vous inscrire, remplissez correctement tous les champs ci-dessous.</h2>
      <div class="container container-fluid" style="margin-top: 12%;margin-left: 18%;">
        <form method="POST" action=".">
          <div class="reg">
            <p class="login-ttl">1. Informations Personelles</p>
            <label for="first_name">
                  <span style="color:black;" class="colored icon-user-o" style="margin-right: 2%;"></span>
            </label>
            
            <input type="text" style="width: 220px;" id="firstname" name="firstname" placeholder="Votre nom" required><br>
            
            <span style="color:black;" class="colored icon-user-o" style="margin-right: -20%;"></span><label for="username" required></label>

            <input type="text" style="width: 220px;" id="lastname" name="lastname" placeholder="Votre prénom" required><br>
            <div class="gndiv">
              <label for="gender">
                <span style="color:black;" class="colored icon-male"></span>
                <span style="color:black;" class="colored icon-female" style="margin-right: 10px;"></span>
              </label>
              <select name="gender" id="gender" class="selector" required>
                <option value="" class="selector-opt">Votre sexe</option>
                <option value="M">Masculin</option><option value="F">Féminin</option>
              </select>
              <br>
            </div>
            <div class="ordiv"><!--A modifier-->
              <label for="origin">
                <span style="color:black;" class="colored icon-map-marker"></span>
                <span style="color:black;" style="margin-right: 10px;"></span>
              </label>
              <select name="origin" id="origin" class="selector" required>
                <option value="">D'où venez-vous?</option>
                <optgroup label="Afrique">
                  <option value="ci">Côte d'Ivoire</option>
                  <option value="gh">Ghana</option>
                  <option value="ml">Mali</option>
                  <option value="tg">Togo</option>
                  <option value="bf">Burkina Faso</option>
                  <option value="za">Afrique du Sud</option>
                </optgroup>
                <optgroup label="Europe">
                  <option value="fr">France</option>
                  <option value="uk">Royaume-Uni</option>
                  <option value="all">Allemagne</option>
                  <option value="ru">Russie</option>
                </optgroup>
                <optgroup label="Amérique">
                  <option value="usa">Etats-Unis</option>
                  <option value="ca">Canada</option>
                </optgroup>
                <optgroup label="Asie">
                  <option value="ch">Chine</option>
                  <option value="jp">Japon</option>
                  <option value="ind">Inde</option>
                  <option value="pak">Pakistan</option>
                </optgroup>
                <optgroup label="Océanie">
                  <option value="aus">Australie</option>
                  <option value="nz">Nouvelle Zélande</option>
                  <option value="fj">Îles Fiji</option>
                </optgroup>
              </select>
              <br>
            </div>
            <label for="email"><span style="color:black;" class="colored icon-envelope" style="margin-right: 20px;"></span></label>
            
            <input name="email" id="email" type="email" style="width: 220px;" placeholder="Adresse email" required>
            
            <br>
            <label for="numtel"><span style="color:black;" class="colored icon-phone" style="margin-right: 20px;"></span></label>

            <input type="tel" style="width: 220px;" name="numtel" id="numtel" placeholder="Numéro de téléphone" required><br>
            
            <span style="color:black;" class="colored icon-user-o" style="margin-right: 20px;"></span>
            <input type="text" style="width: 230px;" name="username" id="username" placeholder="Définissez un nom d'utilisateur" required><br style="margin-top: 5px;">
            <span style="color:black;" class="colored icon-lock" style="margin-right: 20px;"></span>
            <input type="password" style="width: 220px;" name="password" id="password" placeholder="Définissez un mot de passe" required><br>
          </div>

          <div class="reg1">
            <p class="login-ttl" style="margin-left: -9%;">2. Informations Financières</p>
            <span style="margin-left: -8.5%;color:black;">
              <label for="genre">
                <span style="color:black;" class="colored icon-check"></span>
              </label>
              <select name="type_pm" id="type_pm" class="selector" required>
                <option value="">Mode de paiement</option>
                <optgroup label="Cartes bancaires">
                  <option value="visa">Visa</option>
                  <option value="mastercard">Mastercard</option>  
                </optgroup>
                <optgroup label="Mobile Money">
                  <option value="orange">Orange Mobile Money</option>
                  <option value="mtn">MTN Mobile Money</option>
                  <option value="moov">Moov Mobile Money</option>
                </optgroup>
                <optgroup label="Monnaies électroniques">
                  <option value="btc">Bitcoin</option>
                </optgroup>
              </select>
              <br>
            </span>
            <div style="margin-left: -9%">
              <label for="num_cc">
                <span style="color:black;" class='icon-credit-card' style="margin-right: 20px;"></span>
              </label>
              <input type="password" name="num_cc" placeholder="Numéro de compte" size="21" required>
              <br>
            </div>
            <p class="card-indic">Modes de paiement compatibles:</p>
            <div class="allowed-cards">
              <img src="../img/forms/av_visa.png">
              <img src="../img/forms/bitcoin.png" width="50px;">
              <img src="../img/forms/orange.png" width="50px;">
              <br>
              <img src="../img/forms/av_mc.png" width="50px;">
              <img src="../img/forms/moov.jpg" width="50px;">
              <img src="../img/forms/mtn.jfif" width="50px;">
              <br>
              <div style="width: 320px;font-size: 10px;margin-left: 35%;margin-top: 1%;"><h5 style="font-size: 13px;"><strong>P.S : </strong>Les frais de transfert varient selon les opérateurs. Dans tous les cas, ces frais seront crédités sur votre compte.</h5></div>
            </div>
          </div>
          <input type="submit" name="create" value="Valider !" id="sub_btn" style="margin-top: -2%;">
          <p class="connection_advice">Déjà inscrit ? <a href="../login/">Connectez vous !</a></p>  
      </form>
      </div>  
    </section>
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Jadek Group</h2>
              <p>Nous mettons en place des solutions innovantes et fiables pour votre bien-être.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="colored icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="colored icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="colored icon-instagram"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="colored icon-github"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Liens Utiles</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Blog</a></li>
                <li><a href="#" class="py-2 d-block">Contribuer</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Vie Privée</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Qui sommes-nous ?</a></li>
                <li><a href="#" class="py-2 d-block">Contactez Nous</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Nos coordonnées :</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span class="colored icon icon-map-marker"></span><span class="text">École Supérieure Africaine des TIC (ESATIC), Abidjan, Côte d'Ivoire</span></li>
                  <li><a href="#"><span class="colored icon icon-phone"></span><span class="text">+225 02 54 19 52</span></a></li>
                  <li><a href="#"><span class="colored icon icon-envelope"></span><span class="text">jadek_01@gmail.com</span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#2095fe"/></svg></div>


  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/jquery.waypoints.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.magnific-popup.min.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.animateNumber.min.js"></script>
  <script src="../js/jquery.mb.YTPlayer.min.js"></script>
  <script src="../js/bootstrap-datepicker.js"></script>
  <!-- // <script src="../js/jquery.timepicker.min.js"></script> -->
  <script src="../js/scrollax.min.js"></script>
  <script src="../js/main.js"></script>
    
  </body>
</html>