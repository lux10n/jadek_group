<?php
	session_start();
	if(isset($_SESSION["uname"]))
	{
		$conn=true;
		$name=$_SESSION["uname"];
		$fname=$_SESSION['fname'];
		$lname=$_SESSION['lname'];
		$org=$_SESSION['org'];
		/*$pp=$_SESSION['pp'];*/
	}
	else{
		header("Location: login-first");
	}
?>
<!DOCTYPE html>
 <html lang="fr">
 <head>
	<title>Mon Compte - JDG</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="../img/profiles/fav.png">
	<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&display=swap" rel="stylesheet">
	<link rel="icon" href="images/fav.png">
	<link rel="stylesheet" href="../css/open-iconic-bootstrap.min.css">
	<link rel="stylesheet" href="../css/animate.css">
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">
	<link rel="stylesheet" href="../css/magnific-popup.css">

	<link rel="stylesheet" href="../css/aos.css">
	<link rel="stylesheet" href="../css/ionicons.min.css">

	<link rel="stylesheet" href="../css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="../css/jquery.timepicker.css">
	<link rel="stylesheet" href="../css/flaticon.css">
	<link rel="stylesheet" href="../css/icomoon.css">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="account.css">
	<link rel="stylesheet" href="../css/flags/css/flag-icon.css">
 </head>
 <body>
		<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
			<div class="container">
				<li class="navbar-brand">
					<?php
						if($name != "")
						{
							echo('<a href="" style="text-transform: none;"><span><i class="icon icon-user-o"></i></span>  '.$name.'</a>');
						}
						else
						{
							echo("<a href='' style='text-transform: none;'><span><i class='icon icon-user-times'></i></span></a>");
						}
					?>
				</li>
				<a class="navbar-brand" href="index.php">Jadek Group</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
					<span class="oi oi-menu"></span> Menu
				</button>

				<div class="collapse navbar-collapse" id="ftco-nav">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item"><a href="../" class="nav-link">Accueil</a></li>
						<li class="nav-item active"><a href="./" class="nav-link">Mon compte</a></li>
						<li class="nav-item"><a href="" class="nav-link">Contacts</a></li>
					</ul>
				</div>
			</div>
		</nav>
		<div class="hero-wrap" style="background-image: url('../img/walls/account.jpg');">
		    <div class="overlay"></div>
	      	<div class="container">
	        	<div class="row no-gutters slider-text d-flex align-itemd-end justify-content-center">
	        		<div class="col-md-9 ftco-animate text-center d-flex align-items-end justify-content-center">
	          			<div class="text">
				            <h1 class="mb-4 bread">Mon Compte</h1>
		            	</div>
		            </div>
		        </div>
	    	</div>
	    </div>

		<section><br><br><br><br><br>
			<div class="profile-pic">
		</div>
		<br>
		<div class="user-infos">
			<?php 
				echo "<h3><span class='icon-user'></span>	".$fname." ".$lname."	(  @<em>".$name."</em>   )	 <span class='flag-icon flag-icon-".$org."'></span></h3>";
			?>
		</div>
		<div class="programme-match">
			<h2 style="font-family:'Montserrat';text-transform: uppercase;text-align: center;color: black;" class="divtitle">Programme de la CAN</h2>
			<br><p style="text-align: center;">24 équipes divisées en 6 groupes s'affronteront lors de cette CAN.</p><br>
			<div class="container">
				<br>
				<div class="gp1">
					<div class="gA">
					<div class="col-md-6">
						<p class="title">Groupe A</p>
						<div class="team">
							<br><span class="flag-icon flag-icon-ml"></span><span>	Mali</span><span>
							<br><span class="flag-icon flag-icon-gn" style="margin-top: 5%;"></span><span>	Guinée</span>
							<br><span class="flag-icon flag-icon-na" style="margin-top: 5%;"></span><span>	Nambie</span>
							<br><span class="flag-icon flag-icon-ug" style="margin-top: 5%;"></span><span> Ouganda </span>
						</div>
					</div>
					</div>
					<br><br>
					<div class="gB">
					<div class="col-md-6">
						<p class="title">Groupe B</p>
						<div class="team">
							<br><span class="flag-icon flag-icon-bf"></span><span>	Burkina-Faso</span><span>
							<br><span class="flag-icon flag-icon-ci" style="margin-top: 5%;"></span><span>	Côte d'Ivoire</span>
							<br><span class="flag-icon flag-icon-gh" style="margin-top: 5%;"></span><span>	Ghana</span>
							<br><span class="flag-icon flag-icon-cd" style="margin-top: 5%;"></span><span>	RDC</span>
						</div>
					</div>
					</div>
				</div>
				<br><br>		
				<div class="gp2">
					<div class="gC"><div class="col-md-6">
						<p class="title">Groupe C</p>
						<div class="team">
							<br><span class="flag-icon flag-icon-cv"></span><span>	Cap-Vert</span><span>
							<br><span class="flag-icon flag-icon-mz" style="margin-top: 5%;"></span><span>	Mozambique</span>
							<br><span class="flag-icon flag-icon-rw" style="margin-top: 5%;"></span><span>	Rwanda</span>
							<br><span class="flag-icon flag-icon-cm" style="margin-top: 5%;"></span><span>	Cameroun</span>
						</div>
					</div>
					</div>
					<br><br>
					<div class="gD">
					<div class="col-md-6">
						<p class="title">Groupe D</p>
						<div class="team">
							<br><span class="flag-icon flag-icon-mr"></span><span>	Mauritanie</span><span>
							<br><span class="flag-icon flag-icon-ma" style="margin-top: 5%;"></span><span>	Maroc</span>
							<br><span class="flag-icon flag-icon-bi" style="margin-top: 5%;"></span><span>	Burundi</span>
							<br><span class="flag-icon flag-icon-cf" style="margin-top: 5%;"></span><span>	République centrafricaine</span>
						</div>
					</div>
					</div>
				</div>
					<br><br>
				<div class="gp3">
					<div class="gE">
					<div class="col-md-6">
						<p class="title">Groupe E</p>
						<div class="team">
							<br><span class="flag-icon flag-icon-eg"></span><span>	Egypte</span><span>
							<br><span class="flag-icon flag-icon-ke" style="margin-top: 5%;"></span><span>	Kenya</span>
							<br><span class="flag-icon flag-icon-tg" style="margin-top: 5%;"></span><span>	Togo</span>
							<br><span class="flag-icon flag-icon-za" style="margin-top: 5%;"></span><span>	Afrique du Sud</span>
						</div>
					</div>
					</div>
					<br><br>
					<div class="gF">
					<div class="col-md-6">
						<p class="title">Groupe F</p>
						<div class="team">
							<br><span class="flag-icon flag-icon-ne"></span><span>	Niger</span><span>
							<br><span class="flag-icon flag-icon-mg" style="margin-top: 5%;"></span><span>	Madagascar</span>
							<br><span class="flag-icon flag-icon-et" style="margin-top: 5%;"></span><span>	Ethiopie</span>
							<br><span class="flag-icon flag-icon-bj" style="margin-top: 5%;"></span><span>	Bénin</span>
						</div>
					</div>
					</div>
				</div>
			</div>
			<br><br>
			<p style="text-align: center;">52 matchs se dérouleront sur 26 journées.</p>
			<p style="text-align: center;">Ici vous pouvez réserver vos tickets du match que vous souhaiterez regarder, ou simplement le regarder en direct.</p>
			<br>
			<h6 style="text-align: center;text-transform: uppercase;">Programme des journées 1 à 8</h3>
			<br><br>
			<div class="match-journey day1">
				<p class="title" style="margin-left: 6.3%">Journée 1</p>
				<div>
					<span>--
					<p class="title" style="text-decoration: none;">Match 1</p>
					<span class="flag-icon flag-icon-et team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-bj team-logo"></span>
					<p class="match_desc"><span>Ethiopie 0 - 0 Bénin</span></p></span>
					<p class="stadium">Stade d'Ebimpé - <a href="#reservation">Réserver une place</a></p>
					<span>
					<p class="title" style="text-decoration: none;">Match 2</p>
					<span class="flag-icon flag-icon-eg team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-mg team-logo"></span>
					<p class="match_desc"><span>Egypte 0 - 0 Madagascar</span></p></span>
					<p class="stadium">Stade FHB - <a href="#reservation">Réserver une place</a></p>
				</div>
				<p class="title" style="margin-left: 6.3%">Journée 5</p>
				<div>
					<span>
					<p class="title" style="text-decoration: none;">Match 1</p>
					<span class="flag-icon flag-icon-cm team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-ug team-logo"></span>
					<p class="match_desc"><span>Cameroun 0 - 0 Ouganda</span></p></span>
					<p class="stadium">Stade de San-Pedro - <a href="#reservation">Réserver une place</a></p>
					<span>
					<p class="title" style="text-decoration: none;">Match 2</p>
					<span class="flag-icon flag-icon-rw team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-bf team-logo"></span>
					<p class="match_desc"><span>Rwanda 0 - 0 Burkina-Faso</span></p></span>
					<p class="stadium">Stade d'Ebimpé - <a href="#reservation">Réserver une place</a></p>
				</div>
			</div>
			<div class="match-journey day2">
				<p class="title" style="margin-left: 6.3%">Journée 2</p>
				<div>
					<span>
					<p class="title" style="text-decoration: none;">Match 1</p>
					<span class="flag-icon flag-icon-ci team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-ml team-logo"></span>
					<p class="match_desc"><span>Côte d'Ivoire 0 - 0 Mali</span></p></span>
					<p class="stadium1">Stade de la Paix - <a href="#reservation">Réserver une place</a></p>
					<span>
					<p class="title" style="text-decoration: none;">Match 2</p>
					<span class="flag-icon flag-icon-ma team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-gn team-logo"></span>
					<p class="match_desc"><span>Maroc 0 - 0 Guinée</span></p></span>
					<p class="stadium1">Stade de Yamoussoukro - <a href="#reservation">Réserver une place</a></p>
				<p class="title" style="margin-left: 6.3%">Journée 6</p>
				<div>
					<span>
					<p class="title" style="text-decoration: none;">Match 1</p>
					<span class="flag-icon flag-icon-bi team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-gh team-logo"></span>
					<p class="match_desc"><span>Burundi 0 - 0 Ghana</span></p></span>
					<p class="stadium1">Stade de Korhogo - <a href="#reservation">Réserver une place</a></p>
					<span>
					<p class="title" style="text-decoration: none;">Match 2</p>
					<span class="flag-icon flag-icon-cd team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-mz team-logo"></span>
					<p class="match_desc"><span>RDC 0 - 0 Mozambique</span></p></span>
					<p class="stadium1">Stade FHB - <a href="#reservation">Réserver une place</a></p>
				</div>
				</div>
			</div>
			<div class="match-journey day3">
				<p class="title" style="margin-left: 6.3%">Journée 3</p>
				<div>
					<span>
					<p class="title" style="text-decoration: none;">Match 1</p>
					<span class="flag-icon flag-icon-cv team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-na team-logo"></span>
					<p class="match_desc"><span>Cap-Vert 0 - 0 Nambie</span></p></span>
					<p class="stadium2">Stade de Korhogo - <a href="#reservation">Réserver une place</a></p>
					<span>
					<p class="title" style="text-decoration: none;">Match 2</p>
					<span class="flag-icon flag-icon-eg team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-mr team-logo"></span>
					<p class="match_desc"><span>Egypte 0 - 0 Mauritanie</span></p></span>
					<p class="stadium2">Stade de la Paix - <a href="#reservation">Réserver une place</a></p>
				</div>
				<p class="title" style="margin-left: 6.3%">Journée 7</p>
				<div>
					<span>
					<p class="title" style="text-decoration: none;">Match 1</p>
					<span class="flag-icon flag-icon-rw team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-ma team-logo"></span>
					<p class="match_desc"><span>Rwanda 0 - 0 Maroc</span></p></span>
					<p class="stadium2">Stade de San-Pedro - <a href="#reservation">Réserver une place</a></p>
					<span>
					<p class="title" style="text-decoration: none;">Match 2</p>
					<span class="flag-icon flag-icon-eg team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-mr team-logo"></span>
					<p class="match_desc"><span>Egypte 0 - 0 Mauritanie</span></p></span>
					<p class="stadium2">Stade d'Ebimpé - <a href="#reservation">Réserver une place</a></p>
				</div>
			</div>
			<div class="match-journey day4">
				<p class="title" style="margin-left: 6.3%">Journée 4</p>
				<div>
					<span>
					<p class="title" style="text-decoration: none;">Match 1</p>
					<span class="flag-icon flag-icon-ke team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-tg team-logo"></span>	
					<p class="match_desc"><span>Kenya 0 - 0 Togo</span></p></span>
					<p class="stadium3">Stade de San-Pedro - <a href="#reservation">Réserver une place</a></p>
					<span>
					<p class="title" style="text-decoration: none;">Match 2</p>
					<span class="flag-icon flag-icon-za team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-ne team-logo"></span>
					<p class="match_desc"><span>Afrique du Sud 0 - 0 Niger</span></p></span>
					<p class="stadium3">Stade de Yamoussoukro - <a href="#reservation">Réserver une place</a></p>
				</div>
				<p class="title" style="margin-left: 6.3%">Journée 8</p>
				<div>
					<span>
					<p class="title" style="text-decoration: none;">Match 1</p>
					<span class="flag-icon flag-icon-na team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-ke team-logo"></span>
					<p class="match_desc"><span>Nambie 0 - 0 Kenya</span></p></span>
					<p class="stadium3">Stade de Yamoussoukro - <a href="#reservation">Réserver une place</a></p>
					<span>
					<p class="title" style="text-decoration: none;">Match 2</p>
					<span class="flag-icon flag-icon-ci team-logo match"></span><span> <span class="vs">VS</span> </span><span class="flag-icon flag-icon-ma team-logo"></span>
					<p class="match_desc"><span>Côte d'Ivoire 0 - 0 Maroc</span></p></span>
					<p class="stadium3">Stade d'Ebimpé - <a href="#reservation">Réserver une place</a></p>
				</div>
			</div>
		<br id="reservation"><br><br><br>
		<h6 style="text-transform: uppercase;text-align: center;font-family:'Open Sans';">Réserver</h6><br>
		<div>
			<div class="resform">
				<h4>Réserver un ticket de match</h4>
				<p>Pour réserver un ticket de match, remplissez le formulaire ci-dessous.</p>
				<form method="POST" action="../php/stadium_reserv.php">			
					<select name="typeplace" class="selector" style="margin-left: 2%;"required><option value="">Type de place</option><option value="std">Standard</option><option value="vip">VIP</option></select><br>

					<span class="icon-calendar form-icon"></span><select name="journee" class="selector" required><option value="">Journée du match</option><option value="1">Journée n°1</option><option value="2">Journée n°2</option><option value="3">Journée n°3</option><option value="4">Journée n°4</option><option value="5">Journée n°5</option><option value="6">Journée n°6</option><option value="7">Journée n°7</option><option value="8">Journée n°8</option></select><br>
					
					<span class="icon-schedule form-icon"></span><select name="matchnum" class="selector" required><option value="">Numéro de match</option><option value="1">Match n°1</option><option value="2">Match n°2</option></select><br>

					<span class="icon-lock form-icon"></span><input type="password" name="password" placeholder="Votre mot de passe" required>
					<input type="submit" name="reserve" class="btn_sub" value="Réserver !">
				</form>
			</div>
			<div class="resform1" id="hotel">
				<br>
				<h4>Réserver un hôtel</h4>
				<p>Pour réserver une chambre dans un hôtel, remplissez le formulaire ci-dessous.</p>
				<form method="POST" action="../php/hotel_reserv.php">			
					<span class="icon-bed form-icon"></span><select class="selector" name="nomhotel" required><option value="">Nom de l'hôtel</option><optgroup label="Abidjan"><option value="sofitel">Sofitel Abidjan Hôtel Ivoire</option><optgroup label="Yamoussoukro"><option value="presi">Hôtel Président</option></optgroup><optgroup label="Bouaké"><option value="monafrik">Hôtel Mon Afrik</option></optgroup><optgroup label="San-Pedro"><option value="balmer">Nahoui Balmer</option></optgroup><optgroup label="Korhogo"><option value="roseb">Hôtel la Rose Blanche</option></optgroup></select><br>

					<span class="icon-check form-icon"></span><select name="typechambre" class='selector' required><option value="">Type de chambre</option><option value="std">Standard</option><option value="suite">Suite</option></select><br>

					<span class="icon-calendar form-icon"></span><label for="date_entree">Date d'entrée : </label><input type="date" class="date" name="date_entree"><br>
					
					<span class="icon-calendar form-icon"></span><label for="date_sortie">Date de sortie : </label><input type="date" class="date" name="date_sortie"><br>

					<span class="icon-lock form-icon"></span><input type="password" name="password" placeholder="Votre mot de passe" required>
					<input type="submit" name="reserve" class="btn_sub" value="Réserver !">
				</form>
			</div>

		</div>
		<br><br><br><br><br><br><br><br>
		</section>

		<footer class="ftco-footer ftco-bg-dark ftco-section">
			<div class="container">
				<div class="row mb-5">
					<div class="col-md">
						<div class="ftco-footer-widget mb-4">
							<h2 class="ftco-heading-2">Jadek Group</h2>
							<p>Nous mettons en place des solutions innovantes et fiables pour votre bien-être.</p>
							<ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
								<li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
								<li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
								<li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
								<li class="ftco-animate"><a href="#"><span class="icon-github"></span></a></li>
							</ul>
						</div>
					</div>
					<div class="col-md">
						<div class="ftco-footer-widget mb-4 ml-md-5">
							<h2 class="ftco-heading-2">Liens Utiles</h2>
							<ul class="list-unstyled">
								<li><a href="#" class="py-2 d-block">Blog</a></li>
								<li><a href="#" class="py-2 d-block">Contribuer</a></li>
							</ul>
						</div>
					</div>
					<div class="col-md">
						 <div class="ftco-footer-widget mb-4">
							<h2 class="ftco-heading-2">Vie Privée</h2>
							<ul class="list-unstyled">
								<li><a href="#" class="py-2 d-block">Qui sommes-nous ?</a></li>
								<li><a href="#" class="py-2 d-block">Contactez Nous</a></li>
							</ul>
						</div>
					</div>
					<div class="col-md">
						<div class="ftco-footer-widget mb-4">
							<h2 class="ftco-heading-2">Nos Partenaires</h2>
							<div class="block-23 mb-3">
								<ul>
									<li><span><img src=""></span></li>
									<li><span class="icon icon-map-marker"></span><span class="text">École Supérieure Africaine des TIC (ESATIC), Abidjan, Côte d'Ivoire</span></li>
									<li><a href="#"><span class="icon icon-phone"></span><span class="text">+225 02 54 19 52</span></a></li>
									<li><a href="#"><span class="icon icon-envelope"></span><span class="text">jadek_01@gmail.com</span></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 text-center"><a href="../php/disconnect.php">Se déconnecter</a></div>
				</div>
			</div>
		</footer>
<p>
	<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>
	<script src="../js/jquery.min.js"></script>
	<script src="../js/jquery-migrate-3.0.1.min.js"></script>
	<script src="../js/popper.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/jquery.easing.1.3.js"></script>
	<script src="../js/jquery.waypoints.min.js"></script>
	<script src="../js/jquery.stellar.min.js"></script>
	<script src="../js/owl.carousel.min.js"></script>
	<script src="../js/jquery.magnific-popup.min.js"></script>
	<script src="../js/aos.js"></script>
	<script src="../js/jquery.animateNumber.min.js"></script>
	<script src="../js/jquery.mb.YTPlayer.min.js"></script>
	<script src="../js/bootstrap-datepicker.js"></script>
	<!-- // <script src="../js/jquery.timepicker.min.js"></script> -->
	<script src="../js/scrollax.min.js"></script>
	<script src="../js/google-map.js"></script>
	<script src="../js/main.js"></script>
</p>
 </body>
 </html>