<?php
	$connection = mysqli_connect('localhost', 'root', ''); //The Blank string is the password
	mysqli_select_db($connection,'jdg_db');

	$query = "SELECT * FROM user"; //You don't need a ; like you do in SQL
	$result = mysqli_query($connection,$query);

	echo "<table>"; // start a table tag in the HTML

	while($row = mysqli_fetch_array($result)){   //Creates a loop to loop through results
	echo "<tr><td>" . $row['firstname'] . "</td><td>" . $row['lastname'] . "</td></tr>";  //$row['index'] the index here is a field name
	}

	echo "</table>"; //Close the table in HTML
?>