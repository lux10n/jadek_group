<?php
	$dt=date("Y");
	echo(substr(md5($dt),2,10));
	$cnt=mysqli_connect('localhost','root','');
	mysqli_select_db($cnt,'jdg_db');
	$res=mysqli_query($cnt,'SELECT * FROM admin');
	echo(mysqli_fetch_array($res));
?>