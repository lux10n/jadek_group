<?php session_start();
  if(isset($_SESSION['lname'])){
  $name=$_SESSION['lname'];
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Accueil - JDG</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&display=swap" rel="stylesheet"> 
    <link rel="icon" href="img/profiles/fav.png">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
        <li class="navbar-brand">
          <?php
            if(isset($_SESSION["lname"]))
            {
              echo('<a href="account/" style="text-transform: none;"><span><i class="icon icon-user-o"></i></span>  '.$name.'</a>');
            }
            else
            {
              echo("<a href='.' style='text-transform: none;'><span><i class='icon icon-user-times' onclick='alert(\"Connectez vous pour accéder aux pages utilisateur !\")'></i></span></a>");
            }
          ?>
        </li>
        <a class="navbar-brand" href=".">Jadek Group</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active"><a href="." class="nav-link">Accueil</a></li>
            <li class="nav-item"><a href="register/" class="nav-link">Inscription</a></li>
            <li class="nav-item"><a href="login/" class="nav-link">Connexion</a></li>
            <li class="nav-item"><a href="account/" class="nav-link">Mon compte</a></li>
            <li class="nav-item"><a href="reservations/" class="nav-link">Réservations</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->
    <div class="hero">
      <div class="container-wrap d-flex justify-content-end align-items-end">

      </div>
      <section class="home-slider owl-carousel">
        <div class="slider-item" style="background-image: url(img/walls/afrcup.jpg);">
          <div class="overlay"></div>
          <div class="container">
            <div class="row no-gutters slider-text align-items-center">
            <div class="col-md-8 ftco-animate">
              <div class="text mb-5 pb-5">
                <h2 style="font-size:75px;">Vivez la CAN</h2>
                <h2>Un service de qualité pour une clientèle de qualité</h2>
              </div>
            </div>
          </div>
          </div>
        </div>
        <div class="slider-item" style="background-image: url(img/walls/dtrad.jpg);">
          <div class="overlay"></div>
          <div class="container">
            <div class="row no-gutters slider-text align-items-center">
            <div class="col-md-8 ftco-animate">
              <div class="text mb-5 pb-5">
                <h2 style="font-size:75px;">Découvrez la Côte d'Ivoire</h2>
                <h2>Découvrez les richesses touristiques de la Côte d'Ivoire</h2>
              </div>
            </div>
          </div>
          </div>
        </div>
        <div class="slider-item" style="background-image: url(img/walls/regbg.jpg.jpg);">
          <div class="overlay"></div>
          <div class="container">
            <div class="row no-gutters slider-text align-items-center">
            <div class="col-md-8 ftco-animate">
              <div class="text mb-5 pb-5">
                <h2 style="font-size:75px;">Faites vous plaisir !</h2>
                <h2>Une large gamme de services selon votre goût</h2>
              </div>
            </div>
          </div>
          </div>
        </div>
        <div class="slider-item" style="background-image:url(img/walls/bg_2.jpg);">
          <div class="overlay"></div>
          <div class="container">
            <div class="row no-gutters slider-text align-items-center">
            <div class="  col-md-8 ftco-animate">
              <div class="text mb-5 pb-5">
                <h2 style="font-size:75px;">Profitez !</h2>
                <h2>nôtre role, vous faire plaisir</h2>
              </div>
            </div>
          </div>
          </div>
        </div>
      </section>
    </div>
    <br><br>
    <section class="ftco-section ftco-no-pt ftco-no-pb ftco-services-wrap">
      <h2 style="text-align: center;font-family:'Montserrat',sans-serif;text-transform:uppercase;font-size:20px;">Nos infrastructures</h2><br>
      <div class="container">
        <div class="row no-gutters">
          <div class="col-md-3">
            <a href="#stades" class="services-wrap img align-items-end d-flex" style="background-image: url(img/pub/stdium/ebmp_stdm.gif);">
              <div class="text text-center pb-2">
                <h3>Stades</h3>
              </div>
            </a>
          </div>
          <div class="col-md-3">
            <a href="#hotels" class="services-wrap img align-items-end d-flex" style="background-image: url(img/pub/hotels/sofitel_bg.jpg);">
              <div class="text text-center pb-2">
                <h3>Hôtels</h3>
              </div>
            </a>
          </div>
          <div class="col-md-3">
            <a href="#" class="services-wrap img align-items-end d-flex" style="background-image: url(img/walls/ptcd_natres.jpg);">
              <div class="text text-center pb-2">
                <h3>Réserves Naturelles</h3>
              </div>
            </a>
          </div>
          <div class="col-md-3">
            <div class="services-wrap services-overlay img align-items-center d-flex" style="background-image: url(img/pub/stour/ndmb.jpg);">
              <div class="text text-center pb-2">
                <h3 class="mb-0">Sites Touristiques</h3>
                <span>Lieux célèbres</span>
                <div class="d-flex mt-2 justify-content-center">
                <div class="icon">
                  <a href="#tourism"><span class="ion-ios-arrow-forward"></span></a>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <br  id="hotels">
    <section class="ftco-section bg-light ftco-room">
      <div class="container-fluid px-0">
        <div class="row no-gutters justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <span class="subheading">Hôtels</span>
            <h2 class="mb-4">Nos Hôtels</h2>
          </div>
        </div>  
        <div class="row no-gutters">
          <div class="col-lg-6">
            <div class="room-wrap">
              <div class="img d-flex align-items-center" style="background-image: url(img/pub/hotels/rdbh.jpg);">
                <div class="text text-center px-4 py-4">
                  <h2 style="color: #191919;font-family: sans-serif;font-size: 18px; text-transform: uppercase; ">Hôtels Disponibles</h2>
                  <p style="margin-top: 165 px;color: #191919;">Voici quelques hôtels disponibles pour les réservations.</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="room-wrap d-md-flex">
              <a href="#" class="img" style="background-image: url(img/pub/hotels/sofitel_in.jpg);"></a>
              <div class="half left-arrow d-flex align-items-center">
                <div class="text p-4 p-xl-5 text-center">
                  <p class="star mb-0"><span class="ion-ios-star"></span><span class="ion-ios-star"></span><span class="ion-ios-star"></span><span class="ion-ios-star"></span><span class="ion-ios-star"></span></p>
                  <p class="mb-0"><span class="price mr-1"></span> <span class="per">Abidjan</span></p>
                  <h3 class="mb-3"><a href="hotels/sofitel.php">Sofitel Abidjan Hôtel Ivoire</a></h3>
                  <p class=  "pt-1"><a href="hotels/sofitel.php" class="btn-custom px-3 py-2">Plus d'informations    <span class="icon-long-arrow-right"></span></a></p>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="room-wrap d-md-flex">
              <a href="#" class="img order-md-last" style="background-image: url(img/pub/hotels/hpr_int.jpg);"></a>
              <div class="half right-arrow d-flex align-items-center">
                <div class="text p-4 p-xl-5 text-center">
                  <p class="star mb-0"><span class="ion-ios-star"></span></span><span class="ion-ios-star"></span><span class="ion-ios-star"></span><span class="ion-ios-star"></span></p>
                  <p class="mb-0"><span class="per">Yamoussoukro</span></p>
                  <h3 class="mb-3"><a href="hotels/presi.php">Hôtel Président</a></h3>
                  <p class="pt-1"><a href="hotels/presi.php" class="btn-custom px-3 py-2">Plus d'Informations   <span class="icon-long-arrow-right"></span></a></p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="room-wrap d-md-flex">
              <a href="#" class="img order-md-last" style="background-image: url(img/pub/hotels/roseb.jpg);"></a>
              <div class="half right-arrow d-flex align-items-center">
                <div class="text p-4 p-xl-5 text-center">
                  <p class="star mb-0"><span class="ion-ios-star"></span><span class="ion-ios-star"></span><span class="ion-ios-star"></span></p>
                  <p class="mb-0"><span class="per">Korhogo</span></p>
                  <h3 class="mb-3"><a href="hotels/roseb.php">La Rose Blanche</a></h3>
                  <p class="pt-1"><a href="hotels/roseb.php" class="btn-custom px-3 py-2">Plus d'Informations    <span class="icon-long-arrow-right"></span></a></p>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="room-wrap d-md-flex">
              <a href="#" class="img" style="background-image: url(img/pub/hotels/h_monafr.jpg);"></a>
              <div class="half left-arrow d-flex align-items-center">
                <div class="text p-4 p-xl-5 text-center">
                  <p class="star mb-0"><span class="ion-ios-star"></span><span class="ion-ios-star"></p>
                  <p class="mb-0"><span class="per">Bouaké</span></p>
                  <h3 class="mb-3"><a href="hotels/afrik.php">Hôtel Mon Afrik</a></h3>
                  <p class="pt-1"><a href="hotels/afrik.php" class="btn-custom px-3 py-2">Plus d'Informations   <span class="icon-long-arrow-right"></span></a></p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="room-wrap d-md-flex">
              <a href="#" class="img" style="background-image: url(img/pub/hotels/nahoui_balmer.jpg);"></a>
              <div class="half left-arrow d-flex align-items-center">
                <div class="text p-4 p-xl-5 text-center">
                  <p class="star mb-0"></span><span class="ion-ios-star"></span><span class="ion-ios-star"></span><span class="ion-ios-star"></span><span class="ion-ios-star"></span></p>
                  <p class="mb-0"><span class="per">San Pedro</span></p>
                  <h3 class="mb-3"><a href="hotels/balmer.php">Hôtel Nahoui Balmer</a></h3>
                  <p class="pt-1"><a href="hotels/balmer.php" class="btn-custom px-3 py-2">Plus d'Informations   <span class="icon-long-arrow-right"></span></a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <br id="stades">
    <section class="ftco-section ftco-menu" style="background:transparent;">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <span class="subheading">Installations</span>
            <h2>Nos Stades</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img order-md-last" style="background-image: url(img/pub/stdium/ebmp_stdm.gif);"></div>
              <div class="desc pr-3 text-md-right">
                <div class="d-md-flex text align-items-center">
                  <h3 class="order-md-last heading-left"><span>Stade Olympique d'Ébimpé</span></h3>
                </div>
                <div class="d-block">
                  <p>Abidjan</p>
                </div>
              </div>
            </div>
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img order-md-last" style="background-image: url(img/pub/stdium/felicia.jpg);"></div>
              <div class="desc pr-3 text-md-right">
                <div class="d-md-flex text align-items-center">
                  <h3 class="order-md-last heading-left"><span>Stade Félix Houphouët-Boigny</span></h3>
                </div>
                <div class="d-block">
                  <p>Abidjan</p>
                </div>
              </div>
            </div>
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img order-md-last" style="background-image: url(img/pub/stdium/sdbk.jpg);"></div>
              <div class="desc pr-3 text-md-right">
                <div class="d-md-flex text align-items-center">
                  <h3 class="order-md-last heading-left"><span>Stade de la Paix</span></h3>
                  <span class="price price-left"></span>
                </div>
                <div class="d-block">
                  <p>Bouaké</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img" style="background-image: url(img/pub/stdium/stade-korhogo.jpg);"></div>
              <div class="desc pl-3">
                <div class="d-md-flex text align-items-center">
                  <h3><span>Stade de Korhogo</span></h3>
                  <span class="price"></span>
                </div>
                <div class="d-block">
                  <p>Korhogo</p>
                </div>
              </div>
            </div>
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img" style="background-image: url(img/pub/stdium/stade-de-yamoussoukro.jpg);"></div>
              <div class="desc pl-3">
                <div class="d-md-flex text align-items-center">
                  <h3><span>Stade de Yamoussoukro</span></h3>
                  <span class="price"></span>
                </div>
                <div class="d-block">
                  <p id="tourism">Yamoussoukro</p>
                </div>
              </div>
            </div>
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img" style="background-image: url(img/pub/stdium/san_pedro.jpg);"></div>
              <div class="desc pl-3">
                <div class="d-md-flex text align-items-center">
                  <h3><span>Stade de San-Pedro</span></h3>
                  <span class="price price-left"></span>
                </div>
                <div class="d-block">
                  <p>San-Pedro</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-menu" style="background:transparent;margin-top: -5%;">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <span class="subheading"></span>
            <h2>Sites Touristiques</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img order-md-last" style="background-image: url(img/pub/stour/ndmb.jpg);"></div>
              <div class="desc pr-3 text-md-right">
                <div class="d-md-flex text align-items-center">
                  <h3 class="order-md-last heading-left"><span>La Basilique Notre Dame de la Paix</span></h3>
                </div>
                <div class="d-block">
                  <p>Yamoussoukro</p>
                </div>
              </div>
            </div>
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img order-md-last" style="background-image: url(img/pub/stour/musciv.jpg);"></div>
              <div class="desc pr-3 text-md-right">
                <div class="d-md-flex text align-items-center">
                  <h3 class="order-md-last heading-left"><span>Le Musée des Civilisations de Côte d'Ivoire</span></h3>
                </div>
                <div class="d-block">
                  <p>Abidjan</p>
                </div>
              </div>
            </div>
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img order-md-last" style="background-image: url(img/pub/stour/crocolac.jpg);"></div>
              <div class="desc pr-3 text-md-right">
                <div class="d-md-flex text align-items-center">
                  <h3 class="order-md-last heading-left"><span>Le lac aux crocodiles</span></h3>
                  <span class="price price-left"></span>
                </div>
                <div class="d-block">
                  <p>Bingerville</p>
                </div>
              </div>
            </div>
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img order-md-last" style="background-image: url(img/pub/stour/monogaga.jpg);"></div>
              <div class="desc pr-3 text-md-right">
                <div class="d-md-flex text align-items-center">
                  <h3 class="order-md-last heading-left"><span>Les plages de Monogaga</span></h3>
                  <span class="price price-left"></span>
                </div>
                <div class="d-block">
                  <p>San-Pedro</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img" style="background-image: url(img/pub/stour/palaismossou.jpg);"></div>
              <div class="desc pl-3">
                <div class="d-md-flex text align-items-center">
                  <h3><span>La Cour Royale de Mossou</span></h3>
                  <span class="price"></span>
                </div>
                <div class="d-block">
                  <p>Grand-Bassam</p>
                </div>
              </div>
            </div>
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img" style="background-image: url(img/pub/stour/tai_park.jpg);"></div>
              <div class="desc pl-3">
                <div class="d-md-flex text align-items-center">
                  <h3><span>Le Parc National de la Taï</span></h3>
                  <span class="price"></span>
                </div>
                <div class="d-block">
                  <p>Yamoussoukro</p>
                </div>
              </div>
            </div>
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img" style="background-image: url(img/pub/stour/assinie.jpg);"></div>
              <div class="desc pl-3">
                <div class="d-md-flex text align-items-center">
                  <h3><span>Les plages de sable fin</span></h3>
                  <span class="price"></span>
                </div>
                <div class="d-block">
                  <p>Assinie</p>
                </div>
              </div>
            </div>
            <div class="pricing-entry d-flex ftco-animate">
              <div class="img" style="background-image: url(img/pub/stour/stpaul.jpg);"></div>
              <div class="desc pl-3">
                <div class="d-md-flex text align-items-center">
                  <h3><span>La Cathédrale St. Paul</span></h3>
                  <span class="price"></span>
                </div>
                <div class="d-block">
                  <p>Abidjan</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section" style="margin-top: -5%;">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <span class="subheading">Read Blog</span>
            <h2>Informations récentes</h2>
          </div>
        </div>
        <div class="row d-flex">
          <div class="col-md-4 d-flex ftco-animate">
            <div class="blog-entry align-self-stretch">
              <a href="blog-single.html" class="block-20" style="background-image: url('img/walls/blog/blog_1.jpg');">
              </a>
              <div class="text mt-3 text-center">
                <div class="meta mb-2">
                  <div><a href="#">15 Juillet 2020</a></div>
                  <div><a href="#">Admin</a></div>
                  <div><a href="#" class="meta-chat"><span class="icon-chat"></span> 5</a></div>
                </div>
                <h3 class="heading"><a href="#">Les travaux de construction du stade de Korhogo lancés</a></h3>
                <p><a href="" class="btn-custom">Voir Plus</a></p>
              </div>
            </div>
          </div>
          <div class="col-md-4 d-flex ftco-animate">
            <div class="blog-entry align-self-stretch">
              <a href="blog-single.html" class="block-20" style="background-image: url('img/walls/blog/blog_2.jpg');">
              </a>
              <div class="text mt-3 text-center">
                <div class="meta mb-2">
                  <div><a href="#">15 Juillet 2020</a></div>
                  <div><a href="#">Admin</a></div>
                  <div><a href="#" class="meta-chat"><span class="icon-chat"></span> 2</a></div>
                </div>
                <h3 class="heading"><a href="#">Organisation de la Can 2023: Le Cocan entre dans la phase active de ses activités</a></h3>
                <p><a href="" class="btn-custom">Voir Plus</a></p>
              </div>
            </div>
          </div>
          <div class="col-md-4 d-flex ftco-animate">
            <div class="blog-entry align-self-stretch">
              <a href="blog-single.html" class="block-20" style="background-image: url('img/walls/blog/blog_3.jpg');">
              </a>
              <div class="text mt-3 text-center">
                <div class="meta mb-2">
                  <div><a href="#">15 Juillet 2020</a></div>
                  <div><a href="#">Admin</a></div>
                  <div><a href="#" class="meta-chat"><span class="icon-chat"></span> 21</a></div>
                </div>
                <h3 class="heading"><a href="#">Coupe du monde 2022 : Le calendrier de la compétition dévoilé</a></h3>
                <p><a href="#" class="btn-custom">Voir Plus</a></p>
              </div></div></div></div></div></section>
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Jadek Group</h2>
              <p>Nous mettons en place des solutions innovantes et fiables pour votre bien-être.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-github"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Liens Utiles</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Blog</a></li>
                <li><a href="#" class="py-2 d-block">Contribuer</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Vie Privée</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Qui sommes-nous ?</a></li>
                <li><a href="#" class="py-2 d-block">Contactez Nous</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Nos coordonnées :</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span class="icon icon-map-marker"></span><span class="text">École Supérieure Africaine des TIC (ESATIC), Abidjan, Côte d'Ivoire</span></li>
                  <li><a href="#"><span class="icon icon-phone"></span><span class="text">+225 02 54 19 52</span></a></li>
                  <li><a href="#"><span class="icon icon-envelope"></span><span class="text">jadek_01@gmail.com</span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/jquery.mb.YTPlayer.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="..js/google-map.js"></script>
<script src="js/main.js"></script>

  </body>
</html>
<!-- By th3@4 (^_^) -->