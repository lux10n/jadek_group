<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Réservations - JDG</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i" rel="stylesheet">
    <link rel="stylesheet" href="../css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../css/animate.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <link rel="stylesheet" href="../css/aos.css">
    <link rel="stylesheet" href="../css/ionicons.min.css">
    <link rel="stylesheet" href="../css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../css/jquery.timepicker.css">
    <link rel="stylesheet" href="../css/flaticon.css">
    <link rel="stylesheet" href="../css/icomoon.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/reservations.css">    
    <link rel="stylesheet" href="../css/flags/css/flag-icon.css">
    <link rel="icon" href="../img/fav.png">
 </head>
 <body>
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
        <li class="navbar-brand">
          <?php
            $name=$_GET["uname"];
            if($name != "")
            {
              echo('<a href="qrcode/scanner.php?key='.$name.'" style="text-transform: none;"><span><i class="icon icon-user-o"></i></span>  '.base64_decode(base64_decode($name)).'</a>');
            }
            else
            {
              echo("<a href='qrcode/scanner.php?key=none' style='text-transform: none;'><span><i class='icon icon-user-times'></i></span></a>");
            }
          ?>
        </li>
        <a class="navbar-brand" href="index.php">Jadek Group</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active"><a href="index.php" class="nav-link">Accueil</a></li>
            <li class="nav-item"><a href="register.php" class="nav-link">Inscription</a></li>
            <li class="nav-item"><a href="resp/index.php" class="nav-link">Connexion</a></li>
            <li class="nav-item"><a href="account.php" class="nav-link">Mon compte</a></li>
            <li class="nav-item"><a href="reservations.php" class="nav-link">Réservations</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->
		<div class="hero-wrap" style="background-image: url('images/bg2.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text d-flex align-itemd-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center d-flex align-items-end justify-content-center">
          	<div class="text">
	            <h1 class="mb-4 bread">Réservations</h1>
            </div>
          </div>
        </div>
      </div>
    </div>

		<section class="ftco-section ftco-menu" style="background-image: url(images/restaurant-pattern.jpg);">
			<div class="container">
				<div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section text-center ftco-animate">
          	<span class="subheading">Réservations actives</span>
            <h2>Mes réservations de matchs</h2>
          </div>
        </div>
				<div class="row">
        	<div class="col-md-12">
        		<div class="ftco-animate">
        			<?php 
		                $connection=mysqli_connect('localhost','root','');
		                $select_db=mysqli_select_db($connection, 'jdg_db');
		                $user=$_GET['uname'];
		                $query="SELECT * FROM user WHERE username='$user'";
		                $result=mysqli_query($connection, $query);
		                $row=mysqli_fetch_array($result);
		                $uid=$row['firstname'].' '.$row['lastname'];
		                $query="SELECT * FROM match_reserv WHERE nomreservant='$uid'";
		                $result=mysqli_query($connection, $query);
		                $count=mysqli_num_rows($result);
		                $row=mysqli_fetch_array($result);
		                $matchday=$row["journee"];
		                $matchid=$row["matchnum"];
		                $query="SELECT * FROM matchplan WHERE journee='$matchday' AND match_id='$matchid'";
		                $result=mysqli_query($connection, $query);
		                $row1=mysqli_fetch_array($result);
		                echo("<p style='text-align:center;color:black;'>Réservations actives : ".$count."</p>");
		                echo "\n\n\n";
						for ($i=1; $i <= $count; $i++) { 
			                switch ($row1['stade']) {
		                        case 'ebimpe':
		                              $stade="Stade Olympique d'Ebimpé - Abidjan";
		                              $himg="../img/ebmp_stdm.gif";
		                          break;
		                        case 'fhb':
		                              $stade="Hôtel Félix Houphouët-Boigny - Abidjan";
		                              $img="../img/felicia.jpg";
		                          break;
		                        case 'yakro':
		                              $stade="Stade de Yamoussoukro - Yamoussoukro";
		                              $img="../img/stade-de-yamoussoukro.jpg";
		                          break;
		                        case 'sanpedro':
		                              $stade="Stade de San-Pedro - San-Pedro";
		                              $img="../img/san_pedro.jpg";
		                          break;
		                        case 'korhogo':
		                              $stade="Stade de Korhogo - Korhogo";
		                              $img="../img/stade-korhogo.jpg";
		                          break;
		                        case 'bouake':
		                              $stade="Stade de la Paix - Bouaké";
		                              $img="../img/sdbk.jpg";
		                          break;
		                        default:
		                              $stade="";
		                              $img="";
		                          break;
		                      }
		                      switch ($row['typeplace']) {
		                        case 'std':
		                            $typeplace='Place Standard';
		                        break;
		                      case 'vip':
			                        $typeplace='Place VIP';
		                        break;                    
		                      default:
		    	                    $typeplace="";
		                        break;
		                    }
		                    $adv1=$row1['adv1'];
		                    $adv2=$row1['adv2'];
		                    echo("<p style='text-align:center;color:black'>Réservation n° ".$i."</p>");
		                    echo("<div style='margin-left:25%;margin-top:5%;'>
		                			<p>Stade : ".$stade."</p>
		                			<p>Type de réservation : ".$typeplace."</p> 
		                			<p>Match: n° ".$row1['match_id']." de la journée ".$row1['journee']." ;  <span class='flag-icon flag-icon-".$adv1."'style='font-size:35px;'></span><span class='vs'>	VS    </span><span class='flag-icon flag-icon-".$adv2."' style='font-size:35px;'></span>
</p><div class='qrode' style='margin-top:-16%;margin-left:50%;'><a href='https://chart.googleapis.com/chart?cht=qr&chl=match".$row1['journee'].'-'.$row1['match_id'].'utilisateur:'.$row['nomreservant'].';stade:'.$row1['stade']."&chs=600x400'><img src='https://chart.googleapis.com/chart?cht=qr&chl=match".$row1['journee'].'-'.$row1['match_id'].'utilisateur:'.$row['nomreservant'].';stade:'.$row1['stade']."&chs=110x110' width='110px'height='110px;'></a><p style='margin-left:-7%;'>Code QR de la réservation</p>
		                			<p><div class='qrode' style='margin-top:-5%;margin-left:-45%;'><a href='php_classes/stadium_cancel.php?id=".$row['idmatch_reserv']."'>Annuler la réservation</a></div></div>
		                    	");	
					    	}
             			?>
        		</div>
        	</div>
        </div>
			</div>
		</section>
    <section class="ftco-section ftco-menu" style="background-image: url(images/restaurant-pattern.jpg);">
      <div class="container">
        <div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <h2>Mes réservations d'hôtels</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="ftco-animate">
              <?php 
                $connection=mysqli_connect('localhost','root','');
                $select_db=mysqli_select_db($connection, 'jdg_db');
                $user=$_GET['uname'];
                $query="SELECT * FROM user WHERE username='$user'";
                $result=mysqli_query($connection, $query);
                $row=mysqli_fetch_array($result);
                $uid=$row['firstname'].' '.$row['lastname'];
                $query="SELECT * FROM hotel_reserv WHERE nomreservant='$uid'";
                $result=mysqli_query($connection, $query);
                $count=mysqli_num_rows($result);
                $row=mysqli_fetch_array($result);
                echo("<p style='text-align:center;'>Réservations actives : ".$count."</p>");
                echo "\n";
	            for ($i=1; $i <= $count; $i++) { 
	                switch ($row['nomhotel']) {
	                  case 'sofitel':
	                        $hotel="Sofitel Abidjan Hôtel Ivoire";
	                        $himg="../img/sofitel_out.jpg";
	                    break;
	                  case 'presi':
	                        $hotel="Hôtel Président - Yamoussoukro";
	                        $img="../img/hpr_int.jpg";
	                    break;
	                  case 'balmer':
	                        $hotel="Hôtel Nahoui Balmer - San-Pedro";
	                        $img="../img/nahoui_balmer.jpg";
	                    break;
	                  case 'monafrik':
	                        $hotel="Hôtel Mon Afrik - Bouaké";
	                        $img="../img/h_monafr.jpg";
	                    break;
	                  case 'roseb':
	                        $hotel="Hôtel la Rose Blanche - Korhogo";
	                        $img="../img/roseb.jpg";
	                    break;
	                  default:
	                        $hotel="";
	                        $img="";
	                    break;
	                }
	                switch ($row['typechambre']) {
	                  case 'std':
	                      $typechambre='Chambre standard';
	                  break;
	                case 'suite':
	                  $typechambre='Suite';
	                  break;                    
	                default:
	                  $typechambre="";
	                  break;
	              }
	              $date_entree=$row['date_entree'];
	              $date_sortie=$row['date_sortie'];
	              echo("<p style='text-align:center;'>Réservation n°".$i."</p>");
                  echo("<div style='margin-left:25%;margin-top:5%;'>
            			<p>Hôtel : ".$hotel."</p>
            			<p>Type de réservation : ".$typechambre."</p> 
            			<p>Durée de la réservation : ".$date_entree." - ".$date_sortie."</p>
            			</p><div class='qrode' style='margin-top:-16%;margin-left:50%;'><img src='".$himg."' width='110px'height='110px;'><p><a style='margin-top:25%;margin-left;:-35%;' href='php_classes/cancel_hotel.php=".$row['idhotel_reserv']."'>Annuler la réservation</a></p>
            			</div>
                	");            
		         }
	              ?>
            </div>
          </div>
        </div>
      </div>
    </section>
		<footer class="ftco-footer ftco-bg-dark ftco-section">
			<div class="container">
				<div class="row mb-5">
					<div class="col-md">
						<div class="ftco-footer-widget mb-4">
							<h2 class="ftco-heading-2">Jadek Group</h2>
							<p>Nous mettons en place des solutions innovantes et fiables pour votre bien-être.</p>
							<ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
								<li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
								<li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
								<li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
								<li class="ftco-animate"><a href="#"><span class="icon-github"></span></a></li>
							</ul>
						</div>
					</div>
					<div class="col-md">
						<div class="ftco-footer-widget mb-4 ml-md-5">
							<h2 class="ftco-heading-2">Liens Utiles</h2>
							<ul class="list-unstyled">
								<li><a href="#" class="py-2 d-block">Blog</a></li>
								<li><a href="#" class="py-2 d-block">Contribuer</a></li>
							</ul>
						</div>
					</div>
					<div class="col-md">
						 <div class="ftco-footer-widget mb-4">
							<h2 class="ftco-heading-2">Vie Privée</h2>
							<ul class="list-unstyled">
								<li><a href="#" class="py-2 d-block">Qui sommes-nous ?</a></li>
								<li><a href="#" class="py-2 d-block">Contactez Nous</a></li>
							</ul>
						</div>
					</div>
					<div class="col-md">
						<div class="ftco-footer-widget mb-4">
							<h2 class="ftco-heading-2">Nos Partenaires</h2>
							<div class="block-23 mb-3">
								<ul>
									<li><span><img src=""></span></li>
									<li><span class="icon icon-map-marker"></span><span class="text">École Supérieure Africaine des TIC (ESATIC), Abidjan, Côte d'Ivoire</span></li>
									<li><a href="#"><span class="icon icon-phone"></span><span class="text">+225 02 54 19 52</span></a></li>
									<li><a href="#"><span class="icon icon-envelope"></span><span class="text">jadek_01@gmail.com</span></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 text-center"><a href="php_classes/disconnect.php">Se déconnecter</a></div>
				</div>
			</div>
		</footer>
<p>
	<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>
	<script src="../js/jquery.min.js"></script>
	<script src="../js/jquery-migrate-3.0.1.min.js"></script>
	<script src="../js/popper.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/jquery.easing.1.3.js"></script>
	<script src="../js/jquery.waypoints.min.js"></script>
	<script src="../js/jquery.stellar.min.js"></script>
	<script src="../js/owl.carousel.min.js"></script>
	<script src="../js/jquery.magnific-popup.min.js"></script>
	<script src="../js/aos.js"></script>
	<script src="../js/jquery.animateNumber.min.js"></script>
	<script src="../js/jquery.mb.YTPlayer.min.js"></script>
	<script src="../js/bootstrap-datepicker.js"></script>
	<!-- // <script src="../js/jquery.timepicker.min.js"></script> -->
	<script src="../js/scrollax.min.js"></script>
	<script src="../js/google-map.js"></script>
	<script src="../js/main.js"></script>
</p>
 </body>
 </html>