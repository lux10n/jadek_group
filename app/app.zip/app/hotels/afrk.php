<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Sofitel Abidjan Hôtel Ivoire- JDG</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i" rel="stylesheet">
    <link rel="icon" href="../../images/fav.png">
    <link rel="stylesheet" href="../css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../css/animate.css">
    
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">

    <link rel="stylesheet" href="../css/aos.css">

    <link rel="stylesheet" href="../css/ionicons.min.css">

    <link rel="stylesheet" href="../css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="../css/flaticon.css">
    <link rel="stylesheet" href="../css/icomoon.css">
    <link rel="stylesheet" href="../css/style.css">
  </head>
  <body>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
        <li class="navbar-brand">
          <?php
            $name=$_GET["uname"];
            $gender=$_GET["gender"];
            if($name != "")
            {
              echo('<a href="qrcode/scanner.php?key='.$name.'" style="text-transform: none;"><span><i class="icon icon-user-o"></i></span>  '.$name.'</a>');
            }
            else
            {
              echo("<a href='qrcode/scanner.php?key=none' style='text-transform: none;'><span><i class='icon icon-user-times'></i></span></a>");
            }
          ?>
        </li>
        <a class="navbar-brand" href="index.php">Jadek Group</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active"><a href="index.php" class="nav-link">Accueil</a></li>
            <li class="nav-item"><a href="register.php" class="nav-link">Inscription</a></li>
            <li class="nav-item"><a href="resp/index.php" class="nav-link">Connexion</a></li>
            <li class="nav-item"><a href="account.php" class="nav-link">Mon compte</a></li>
            <li class="nav-item"><a href="contact.php" class="nav-link">Contacts</a></li>
          </ul>
        </div>
      </div>
    </nav>    <!-- END nav -->
		<div class="hero-wrap" style="background-image: url('../images/sofitel/bg2.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text d-flex align-itemd-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center d-flex align-items-end justify-content-center">
          	<div class="text">
	            <p class="breadcrumbs mb-2"><span class="mr-2"><a href="index.php#hotels">Hôtels</a></span> <span>Sofitel Abidjan Hôtel Ivoire</span></p>
	            <h1 class="mb-4 bread">Sofitel Abidjan Hôtel Ivoire</h1>
            </div>
          </div>
        </div>
      </div>
    </div>

		<section class="ftco-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
          	<div class="row">
          		<div class="col-md-12 ftco-animate">
          			<div class="single-slider owl-carousel">
          				<div class="item">
          					<div class="room-img" style="background-image: url(../images/sofitel/bg.jpg);"></div>
          				</div>
          				<div class="item">
          					<div class="room-img" style="background-image: url(../images/sofitel/recept.webp);"></div>
          				</div>
          				<div class="item">
          					<div class="room-img" style="background-image: url(../images/sofitel/1.jpg);"></div>
          				</div>
                  <div class="item">
                    <div class="room-img" style="background-image: url(../images/sofitel/2.jpg);"></div>
                  </div>                  
          			</div>
          		</div>
          		<div class="col-md-12 room-single mt-4 mb-5 ftco-animate">
          			<h2 class="mb-4">Hotel de luxe</h2>
    						<p>Dans cet hôtel international 5 étoiles d'Abidjan, Sofitel marie luxe français et charme africain. Dominant la lagune Ebrié et le Plateau, cet hôtel de luxe de la Côte d'Ivoire s'élève majestueusement au-dessus d'un décor d'eau et de végétations.</p>
    						<div class="d-md-flex mt-5 mb-5">
    							<ul class="list">
	    							<li><span>Nombre de chambres :</span> 429</li>
	    							<li><span>Size:</span> 40 - 88 m</li>
	    						</ul>
	    						<ul class="list ml-md-5">
	    							<li><span>Vues possibles:</span> Vue sur la ville / Vue sur la lagune Ébrié</li>
	    							<li><span>Lits par chambre :</span> 1-2</li>
                    <li><span>Lits par suite :</span> 1-3</li>
	    						</ul>
    						</div>
    						<p>Un confort absolu et une sophistication extrême à retrouver dans les Suites Prestige Sofitel, exceptionnellement proposées à des prix très privilégiés dont nous vous invitons à profiter... en réservant sans tarder !</p>
          		</div>
          		<div class="col-md-12 room-single ftco-animate mb-5 mt-4">
          			<div class="block-16">
		              <figure style="margin-left: -10%;"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d89663.40639061331!2d-5.3899586168513425!3d6.8596974566010065!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfb8973447dfb0f7%3A0x3183f2cbe8b45c7c!2sH%C3%B4tel%20President!5e0!3m2!1sen!2sci!4v1594939009309!5m2!1sen!2sci" width="800" height="300" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe></figure>
		            </div>
          		</div>

          		<div class="col-md-12 properties-single ftco-animate mb-5 mt-4">
          			<h4 class="mb-4">Classement</h4>
          			<div class="row">
          				<div class="col-md-6">
          					<form method="post" class="star-rating">
										  <div class="form-check">
												<label class="form-check-label" for="exampleCheck1">
													<p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i> 120 votes</span></p>
												</label>
										  </div>
										  <div class="form-check">
									      <label class="form-check-label" for="exampleCheck1">
									    	   <p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-o"></i> 30 votes</span></p>
									      </label>
										  </div>
										  <div class="form-check">
									      <label class="form-check-label" for="exampleCheck1">
									      	<p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-o"></i><i class="icon-star-o"></i> 2 votes</span></p>
									     </label>
										  </div>
										  <div class="form-check">
									      <label class="form-check-label" for="exampleCheck1">
									      	<p class="rate"><span><i class="icon-star"></i><i class="icon-star"></i><i class="icon-star-o"></i><i class="icon-star-o"></i><i class="icon-star-o"></i> 0 votes</span></p>
									      </label>
										  </div>
										  <div class="form-check">
									      <label class="form-check-label" for="exampleCheck1">
									      	<p class="rate"><span><i class="icon-star"></i><i class="icon-star-o"></i><i class="icon-star-o"></i><i class="icon-star-o"></i><i class="icon-star-o"></i> 0 votes</span></p>
										    </label>
										  </div>
										</form>
          				</div>
          			</div>
          		</div>
          	</div>
          </div> <!-- .col-md-8 -->
          <div class="col-lg-4 sidebar ftco-animate">
            <div class="sidebar-box">
              <form action="#" class="search-form">
                <div class="form-group">
                  <span class="icon ion-ios-search"></span>
                  <input type="text" class="form-control" placeholder="Rechercher...">
                </div>
              </form>
            </div>
            <div class="sidebar-box ftco-animate">
              <div class="categories">
                <h3>Caractéristiques</h3>
                <li><span class="icon-map-marker"></span>   Plateau, Abidjan</li>
                <li><span class="icon-money"></span>    Prix minimum : 126 000 XOF</li>
                <li><span class="icon-pool"></span>   Grandes piscines en plein air</li>
                <li><span class="icon-spa"></span>    Spa disponible</li>
                <li><span class="icon-wifi"></span>   Wi-Fi haut débit</li>
                <li><span class="icon-local_parking"></span>    Parking gratuit</a></li>
                <li><span class="icon-restaurant"></span>   Restaurants intérieurs et en plein air</li>
                <li><span class="icon-users"></span>   Grande salle de conférence</li>
                <li><span class="icon-bed"></span>
                  <?php
                    if ($_GET["uname"]!="")
                    {
                      $i=base64_encode('sofitel');
                      echo("<a href='../account.php?reservID=".$i."' style='display:inline-block;'>    Réserver</a>");
                    }
                    else{
                      echo(" Pour réserver, il faut être <a href='../reg/register.php'>connecté</a>");
                    }
                  ?>
                </li>
              </div>
            </div>

            <div class="sidebar-box ftco-animate">
              <h3>Voir aussi</h3>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(../images/sofitel/bg2.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="">Faites un tour au coeur du Sofitel Abidjan Hôtel Ivoire</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> 15 Juillet 2020</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                    <div><a href="#"><span class="icon-chat"></span> 35</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(../images/sofitel/blog_1.png);"></a>
                <div class="text">
                  <h3 class="heading"><a href="https://fr-fr.facebook.com/pg/SofitelAbidjan">Plus d'informations sur les évènements à venir au Sofitel Abidjan Hôtel Ivoire</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> 15 Juillet 2020</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                    <div><a href="#"><span class="icon-chat"></span> 40</a></div>
                  </div>
                </div>
              </div>
              <div class="block-21 mb-4 d-flex">
                <a class="blog-img mr-4" style="background-image: url(../images/blog_2.jpg);"></a>
                <div class="text">
                  <h3 class="heading"><a href="https://www.ladiplomatiquedabidjan.com/economie/395-hotellerie-la-nouvelle-aile-du-sofitel-abidjan-hotel-ivoire-fonctionnelle.html">La nouvelle aile du Sofitel Abidjan Hôtel Ivoire</a></h3>
                  <div class="meta">
                    <div><a href="#"><span class="icon-calendar"></span> 15 Juillet 2020</a></div>
                    <div><a href="#"><span class="icon-person"></span> Admin</a></div>
                    <div><a href="#"><span class="icon-chat"></span> 30</a></div>
                  </div>
                </div>
              </div>
            </div>

            <div class="sidebar-box ftco-animate">
              <h3>Tags</h3>
              <div class="tagcloud">
                <a href="#" class="tag-cloud-link">chambre</a>
                <a href="#" class="tag-cloud-link">menu</a>
                <a href="#" class="tag-cloud-link">food</a>
                <a href="#" class="tag-cloud-link">suite</a>
                <a href="#" class="tag-cloud-link">dessert</a>
                <a href="#" class="tag-cloud-link">salon</a>
                <a href="#" class="tag-cloud-link">piscine</a>
                <a href="#" class="tag-cloud-link">boissons</a>
              </div>
            </div>

            <div class="sidebar-box ftco-animate">
              <h3>Info Utile</h3>
              <p>L'hôtel Ivoire a accueilli la 5e édition du sommet UA-UE. C'est aussi l'endroit idéal pour des cérémonies non-officielles. C'est donc un lieu propice aussi bien aux affaires qu'aux vacances !</p>
            </div>
          </div>
        </div>
      </div>
    </section> <!-- .section -->
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Jadek Group</h2>
              <p>Nous mettons en place des solutions innovantes et fiables pour votre bien-être.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-github"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Liens Utiles</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Blog</a></li>
                <li><a href="#" class="py-2 d-block">Contribuer</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Vie Privée</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Qui sommes-nous ?</a></li>
                <li><a href="#" class="py-2 d-block">Contactez Nous</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Nos Partenaires</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span><img src=""></span></li>
                  <li><span class="icon icon-map-marker"></span><span class="text">École Supérieure Africaine des TIC (ESATIC), Abidjan, Côte d'Ivoire</span></li>
                  <li><a href="#"><span class="icon icon-phone"></span><span class="text">+225 02 54 19 52</span></a></li>
                  <li><a href="#"><span class="icon icon-envelope"></span><span class="text">jadek_01@gmail.com</span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">
          </div>
        </div>
      </div>
    </footer>

    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/jquery.waypoints.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.magnific-popup.min.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.animateNumber.min.js"></script>
  <script src="../js/jquery.mb.YTPlayer.min.js"></script>
  <script src="../js/bootstrap-datepicker.js"></script>
  <!-- // <script src="../js/jquery.timepicker.min.js"></script> -->
  <script src="../js/scrollax.min.js"></script>
  <script src="../js/google-map.js"></script>
  <script src="../js/main.js"></script>
    
  </body>
</html>